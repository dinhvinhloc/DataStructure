﻿using System;

namespace FacadeDemo_QuickTeaFacade
{
    internal class Water
    {
        internal void boil()
        {
            Console.WriteLine("Water boiled");
        }
    }
}