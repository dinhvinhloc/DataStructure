﻿namespace FacadeDemo_QuickTeaFacade
{
    internal class Tea
    {
        public Tea()
        {
        }
    }
}