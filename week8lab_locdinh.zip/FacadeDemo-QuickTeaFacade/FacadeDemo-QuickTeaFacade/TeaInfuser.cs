﻿using System;

namespace FacadeDemo_QuickTeaFacade
{
    internal class TeaInfuser
    {
        internal void addTea(Tea tea)
        {
            Console.WriteLine("Tea added");
        }
    }
}