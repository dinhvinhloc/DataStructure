﻿

namespace FacadeDemo_QuickTeaFacade
{
    class Program
    {
        static void Main(string[] args)
        {
            QuickTea quicktea = new QuickTea();
            quicktea.MakeTea();
           
        }
    }
}
