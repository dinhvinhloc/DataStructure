﻿namespace FactoryLab
{
    
    interface IShape
    {
        string GetShapeName();
        double GetArea();
        double GetPerimeter();
    }
}