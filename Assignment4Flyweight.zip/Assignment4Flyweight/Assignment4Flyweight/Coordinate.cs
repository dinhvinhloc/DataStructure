﻿namespace Assignment4Flyweight
{
    internal class Coordinate
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}